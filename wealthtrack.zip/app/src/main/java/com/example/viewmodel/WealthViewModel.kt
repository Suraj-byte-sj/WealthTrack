package com.example.viewmodel

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import com.example.data.local.AppDatabase
import com.example.data.model.Investment
import com.example.data.model.InvestmentAlert
import com.example.data.model.Transaction
import com.example.data.repository.WealthRepository
import com.example.util.CurrencyFormatter
import com.example.util.toCurrencyString
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class WealthViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: WealthRepository
    private val sharedPrefs = application.getSharedPreferences("wealth_track_prefs", Context.MODE_PRIVATE)

    // Reactive data flows
    val transactions: StateFlow<List<Transaction>>
    val investments: StateFlow<List<Investment>>
    val alerts: StateFlow<List<InvestmentAlert>>

    // Budget goal loaded from SharedPreferences
    private val _budgetGoal = MutableStateFlow(300000.0)
    val budgetGoal: StateFlow<Double> = _budgetGoal.asStateFlow()

    // Currency locale selected by the user
    private val _preferredLocale = MutableStateFlow(CurrencyFormatter.CurrencyLocale.SYSTEM)
    val preferredLocale: StateFlow<CurrencyFormatter.CurrencyLocale> = _preferredLocale.asStateFlow()

    // Biometric Lock preference and unlocked state
    private val _biometricLockEnabled = MutableStateFlow(false)
    val biometricLockEnabled: StateFlow<Boolean> = _biometricLockEnabled.asStateFlow()

    private val _isUnlocked = MutableStateFlow(true)
    val isUnlocked: StateFlow<Boolean> = _isUnlocked.asStateFlow()

    // Base liquid cash baseline for high-net-worth theme
    private val _baseCash = MutableStateFlow(1250000.0)
    val baseCash: StateFlow<Double> = _baseCash.asStateFlow()

    // Base liabilities baseline for high-net-worth theme
    private val _baseLiabilities = MutableStateFlow(450000.0)
    val baseLiabilities: StateFlow<Double> = _baseLiabilities.asStateFlow()

    // Snackbar events state
    private val _snackbarMessage = MutableSharedFlow<String>()
    val snackbarMessage = _snackbarMessage.asSharedFlow()

    init {
        val database = AppDatabase.getDatabase(application)
        repository = WealthRepository(database.transactionDao(), database.investmentDao(), database.investmentAlertDao())

        // Load SharedPreferences budget goal (default 300,000 USD)
        val savedBudget = sharedPrefs.getFloat("monthly_budget", 300000f).toDouble()
        _budgetGoal.value = savedBudget

        // Load preferred currency locale
        val savedLocale = sharedPrefs.getString("preferred_currency_locale", "SYSTEM") ?: "SYSTEM"
        _preferredLocale.value = CurrencyFormatter.CurrencyLocale.fromName(savedLocale)

        // Load biometric settings and status
        val savedBiometric = sharedPrefs.getBoolean("biometric_lock_enabled", false)
        _biometricLockEnabled.value = savedBiometric
        _isUnlocked.value = !savedBiometric

        // Define StateFlows
        transactions = repository.allTransactions.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        investments = repository.allInvestments.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        alerts = repository.allAlerts.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        // Seed database if empty
        viewModelScope.launch {
            repository.seedDatabaseIfEmpty()
        }

        // Setup real-time alert monitoring
        viewModelScope.launch {
            repository.allInvestments.collect { updatedInvestments ->
                checkAlerts(updatedInvestments)
            }
        }
    }

    // Set budget goal
    fun updateBudgetGoal(goal: Double) {
        viewModelScope.launch {
            _budgetGoal.value = goal
            sharedPrefs.edit().putFloat("monthly_budget", goal.toFloat()).apply()
            val formattedGoal = goal.toCurrencyString(_preferredLocale.value, includeDecimals = true)
            showSnackbar("Budget goal updated to $formattedGoal")
        }
    }

    // Set preferred currency locale
    fun updatePreferredLocale(locale: CurrencyFormatter.CurrencyLocale) {
        viewModelScope.launch {
            _preferredLocale.value = locale
            sharedPrefs.edit().putString("preferred_currency_locale", locale.name).apply()
            showSnackbar("Currency locale set to: ${locale.displayName}")
        }
    }

    // Update Biometric lock preference
    fun updateBiometricLockEnabled(enabled: Boolean) {
        viewModelScope.launch {
            _biometricLockEnabled.value = enabled
            sharedPrefs.edit().putBoolean("biometric_lock_enabled", enabled).apply()
            if (!enabled) {
                _isUnlocked.value = true
            }
            showSnackbar(if (enabled) "Biometric Lock Enabled" else "Biometric Lock Disabled")
        }
    }

    // Set lock/unlocked state dynamically
    fun setUnlocked(unlocked: Boolean) {
        _isUnlocked.value = unlocked
    }

    // Insert new transaction with validation
    fun addTransaction(amount: Double, category: String, description: String, type: String): Boolean {
        if (amount <= 0) {
            showSnackbar("Validation Error: Amount must be greater than 0")
            return false
        }
        if (category.isBlank()) {
            showSnackbar("Validation Error: Category must be selected")
            return false
        }
        if (description.isBlank()) {
            showSnackbar("Validation Error: Description cannot be empty")
            return false
        }

        viewModelScope.launch {
            val transaction = Transaction(
                amount = amount,
                category = category,
                date = System.currentTimeMillis(),
                description = description,
                type = type
            )
            repository.insertTransaction(transaction)
            showSnackbar("Successfully added $type: $description")
        }
        return true
    }

    // Delete transaction
    fun deleteTransaction(transaction: Transaction) {
        viewModelScope.launch {
            repository.deleteTransaction(transaction)
            showSnackbar("Deleted transaction: ${transaction.description}")
        }
    }

    // Insert new investment
    fun addInvestment(name: String, amountInvested: Double, currentValue: Double, purchaseDate: String): Boolean {
        if (name.isBlank() || amountInvested <= 0 || currentValue <= 0 || purchaseDate.isBlank()) {
            showSnackbar("Validation Error: Please fill in all investment details correctly")
            return false
        }
        viewModelScope.launch {
            val investment = Investment(
                name = name,
                amountInvested = amountInvested,
                currentValue = currentValue,
                purchaseDate = purchaseDate
            )
            repository.insertInvestment(investment)
            showSnackbar("Successfully added investment: $name")
        }
        return true
    }

    // Delete investment
    fun deleteInvestment(investment: Investment) {
        viewModelScope.launch {
            repository.deleteInvestment(investment)
            showSnackbar("Deleted investment: ${investment.name}")
        }
    }

    // Helper to send snackbar message
    fun showSnackbar(message: String) {
        viewModelScope.launch {
            _snackbarMessage.emit(message)
        }
    }

    // Clear all DB entries for testing/reset
    fun resetDatabase() {
        viewModelScope.launch {
            repository.clearAll()
            repository.seedDatabaseIfEmpty()
            showSnackbar("Database successfully reset to seed data")
        }
    }

    // Create price alert
    fun addAlert(investmentId: Int, investmentName: String, targetPrice: Double, isAbove: Boolean): Boolean {
        if (targetPrice <= 0) {
            showSnackbar("Validation Error: Threshold price must be greater than 0")
            return false
        }
        viewModelScope.launch {
            val alert = InvestmentAlert(
                investmentId = investmentId,
                investmentName = investmentName,
                targetPrice = targetPrice,
                isAbove = isAbove,
                isTriggered = false
            )
            repository.insertAlert(alert)
            showSnackbar("Set price threshold alert for $investmentName at $$targetPrice")
        }
        return true
    }

    // Delete alert
    fun deleteAlert(alert: InvestmentAlert) {
        viewModelScope.launch {
            repository.deleteAlert(alert)
            showSnackbar("Deleted alert for ${alert.investmentName}")
        }
    }

    // Update tracked investment value
    fun updateInvestmentValue(investment: Investment, newValue: Double): Boolean {
        if (newValue <= 0) {
            showSnackbar("Validation Error: Value must be greater than 0")
            return false
        }
        viewModelScope.launch {
            val updated = investment.copy(currentValue = newValue)
            repository.insertInvestment(updated)
            showSnackbar("Updated ${investment.name} holding value to $$newValue")
        }
        return true
    }

    // Evaluate active alerts against current prices
    private fun checkAlerts(investments: List<Investment>) {
        viewModelScope.launch {
            val active = repository.activeAlerts.first()
            active.forEach { alert ->
                val investment = investments.find { it.id == alert.investmentId }
                if (investment != null) {
                    val price = investment.currentValue
                    val isTriggered = if (alert.isAbove) {
                        price >= alert.targetPrice
                    } else {
                        price <= alert.targetPrice
                    }
                    if (isTriggered) {
                        // Mark as triggered to prevent spam
                        repository.updateAlert(alert.copy(isTriggered = true))
                        // Fire notification
                        sendNotification(alert, price)
                    }
                }
            }
        }
    }

    // System Status Bar Notification Dispatcher
    private fun sendNotification(alert: InvestmentAlert, currentPrice: Double) {
        val context = getApplication<Application>()
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channelId = "investment_alerts_channel"

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Investment Price Alerts",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Triggers when tracked investment price crosses designated thresholds"
            }
            notificationManager.createNotificationChannel(channel)
        }

        val intent = Intent(context, com.example.MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            alert.id,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val direction = if (alert.isAbove) "ascended above" else "descended below"
        val formattedTarget = String.format("$%,.2f", alert.targetPrice)
        val formattedCurrent = String.format("$%,.2f", currentPrice)

        val notification = androidx.core.app.NotificationCompat.Builder(context, channelId)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Sovereign Price Alert: ${alert.investmentName}")
            .setContentText("The value has $direction the target threshold of $formattedTarget. Current value: $formattedCurrent")
            .setPriority(androidx.core.app.NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()

        notificationManager.notify(alert.id, notification)
        showSnackbar("🔔 ALERT TRIGGERED: ${alert.investmentName} has reached your threshold of $formattedTarget!")
    }
}
