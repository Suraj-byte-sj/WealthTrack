package com.example

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.biometric.BiometricPrompt
import androidx.biometric.BiometricManager
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModelProvider
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.ReportsScreen
import com.example.ui.screens.TransactionsScreen
import com.example.ui.screens.VaultLockScreen
import com.example.ui.theme.*
import com.example.viewmodel.WealthViewModel
import kotlinx.coroutines.flow.collectLatest
import java.util.Locale
import androidx.compose.foundation.layout.ExperimentalLayoutApi

class MainActivity : FragmentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                // Instantiate the ViewModel using the factory that provides Application context
                val viewModel: WealthViewModel = ViewModelProvider(
                    this,
                    ViewModelProvider.AndroidViewModelFactory.getInstance(application)
                )[WealthViewModel::class.java]

                MainContainer(viewModel = viewModel)
            }
        }
    }

    fun authenticateBiometric(onSuccess: () -> Unit, onError: (String) -> Unit) {
        val executor = ContextCompat.getMainExecutor(this)
        val biometricPrompt = BiometricPrompt(this, executor, object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                super.onAuthenticationSucceeded(result)
                onSuccess()
            }

            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                super.onAuthenticationError(errorCode, errString)
                onError(errString.toString())
            }

            override fun onAuthenticationFailed() {
                super.onAuthenticationFailed()
                onError("Biometric verification failed")
            }
        })

        val promptInfo = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Sovereign Ledger Unlock")
            .setSubtitle("Authenticate using your biometric credential to access account records.")
            .setNegativeButtonText("Cancel")
            .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.BIOMETRIC_WEAK)
            .build()

        try {
            biometricPrompt.authenticate(promptInfo)
        } catch (e: Exception) {
            onError(e.message ?: "Could not initialize biometric unlock")
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainContainer(viewModel: WealthViewModel) {
    val isUnlocked by viewModel.isUnlocked.collectAsState()
    var activeTab by remember { mutableStateOf("Dashboard") }
    var showAddDialog by remember { mutableStateOf(false) }

    val snackbarHostState = remember { SnackbarHostState() }

    // Coroutine scope to collect snackbars
    LaunchedEffect(key1 = true) {
        viewModel.snackbarMessage.collectLatest { message ->
            snackbarHostState.showSnackbar(message)
        }
    }

    if (!isUnlocked) {
        VaultLockScreen(viewModel = viewModel)
    } else {

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = WealthDarkBg,
        snackbarHost = { SnackbarHost(hostState = snackbarHostState, modifier = Modifier.testTag("main_snackbar_host")) },
        bottomBar = {
            NavigationBar(
                containerColor = WealthCardBg,
                tonalElevation = 8.dp,
                modifier = Modifier.testTag("bottom_nav_bar")
            ) {
                listOf(
                    NavigationItem("Dashboard", Icons.Default.Dashboard, "Dashboard"),
                    NavigationItem("Transactions", Icons.Default.History, "Transactions"),
                    NavigationItem("Reports", Icons.Default.PieChart, "Reports"),
                    NavigationItem("Profile", Icons.Default.Person, "Profile")
                ).forEach { item ->
                    NavigationBarItem(
                        selected = activeTab == item.name,
                        onClick = { activeTab = item.name },
                        icon = {
                            Icon(
                                imageVector = item.icon,
                                contentDescription = item.contentDescription,
                                modifier = Modifier.size(24.dp)
                            )
                        },
                        label = {
                            Text(
                                text = item.name,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = if (activeTab == item.name) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.Black,
                            selectedTextColor = WealthGold,
                            indicatorColor = WealthGold,
                            unselectedIconColor = WealthTextMuted,
                            unselectedTextColor = WealthTextMuted
                        ),
                        modifier = Modifier.testTag("nav_tab_${item.name.lowercase(Locale.ROOT)}")
                    )
                }
            }
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = WealthGold,
                contentColor = Color.Black,
                shape = CircleShape,
                modifier = Modifier.testTag("add_transaction_fab")
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "Add Transaction",
                    modifier = Modifier.size(28.dp)
                )
            }
        },
        floatingActionButtonPosition = FabPosition.End,
        contentWindowInsets = WindowInsets.safeDrawing
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (activeTab) {
                "Dashboard" -> DashboardScreen(viewModel = viewModel)
                "Transactions" -> TransactionsScreen(viewModel = viewModel)
                "Reports" -> ReportsScreen(viewModel = viewModel)
                "Profile" -> ProfileScreen(viewModel = viewModel)
            }
        }

        // Add Transaction Dialog
        if (showAddDialog) {
            AddTransactionDialog(
                onDismiss = { showAddDialog = false },
                onConfirm = { amount, category, description, type ->
                    val success = viewModel.addTransaction(amount, category, description, type)
                    if (success) {
                        showAddDialog = false
                    }
                }
            )
        }
    }
    }
}

data class NavigationItem(
    val name: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val contentDescription: String
)

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun AddTransactionDialog(
    onDismiss: () -> Unit,
    onConfirm: (Double, String, String, String) -> Unit
) {
    var amountInput by remember { mutableStateOf("") }
    var descriptionInput by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("Food") }
    var selectedType by remember { mutableStateOf("expense") } // "income" or "expense"

    var validationError by remember { mutableStateOf<String?>(null) }

    val categories = listOf("Food", "Transport", "Shopping", "Bills", "Entertainment", "Others")

    AlertDialog(
        onDismissRequest = onDismiss,
        properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false),
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
            .testTag("add_transaction_dialog"),
        content = {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = WealthCardBg,
                border = androidx.compose.foundation.BorderStroke(1.dp, WealthGold.copy(alpha = 0.2f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .padding(24.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Header
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "RECORD TRANSACTION",
                            style = MaterialTheme.typography.titleMedium,
                            color = WealthGold,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                        IconButton(
                            onClick = onDismiss,
                            modifier = Modifier.size(24.dp).testTag("close_dialog_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Close Dialog",
                                tint = WealthTextMuted
                            )
                        }
                    }

                    HorizontalDivider(color = Color.White.copy(alpha = 0.08f))

                    // Type Picker: Segmented Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("expense", "income").forEach { type ->
                            val isSelected = selectedType == type
                            Button(
                                onClick = { selectedType = type },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(40.dp)
                                    .testTag("dialog_type_$type"),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isSelected) {
                                        if (type == "income") WealthGreen else WealthRed
                                    } else Color.White.copy(alpha = 0.03f),
                                    contentColor = if (isSelected) Color.Black else WealthTextPrimary
                                ),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(
                                    text = type.uppercase(Locale.ROOT),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }

                    // Amount Textfield (Filled Style)
                    TextField(
                        value = amountInput,
                        onValueChange = { amountInput = it },
                        label = { Text("Amount (USD)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = WealthDarkBg,
                            unfocusedContainerColor = WealthDarkBg,
                            focusedLabelColor = WealthGold,
                            unfocusedLabelColor = WealthTextMuted,
                            focusedIndicatorColor = WealthGold,
                            unfocusedIndicatorColor = Color.Transparent,
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("dialog_amount_input")
                    )

                    // Description Textfield (Filled Style)
                    TextField(
                        value = descriptionInput,
                        onValueChange = { descriptionInput = it },
                        label = { Text("Description") },
                        singleLine = true,
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = WealthDarkBg,
                            unfocusedContainerColor = WealthDarkBg,
                            focusedLabelColor = WealthGold,
                            unfocusedLabelColor = WealthTextMuted,
                            focusedIndicatorColor = WealthGold,
                            unfocusedIndicatorColor = Color.Transparent,
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("dialog_description_input")
                    )

                    // Category Selection
                    Column {
                        Text(
                            text = "SELECT CATEGORY",
                            style = MaterialTheme.typography.labelSmall,
                            color = WealthTextMuted,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.5.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        // Display category list grid
                        FlowRow(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp),
                            maxItemsInEachRow = 3
                        ) {
                            categories.forEach { cat ->
                                val isSelected = selectedCategory == cat
                                Surface(
                                    shape = RoundedCornerShape(50.dp),
                                    color = if (isSelected) WealthGold.copy(alpha = 0.15f) else Color.White.copy(alpha = 0.03f),
                                    border = if (isSelected) androidx.compose.foundation.BorderStroke(1.dp, WealthGold) else null,
                                    modifier = Modifier
                                        .clickable { selectedCategory = cat }
                                        .testTag("dialog_category_chip_$cat")
                                ) {
                                    Text(
                                        text = cat,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (isSelected) WealthGold else WealthTextPrimary,
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                                    )
                                }
                            }
                        }
                    }

                    // Validation Error Text
                    if (validationError != null) {
                        Text(
                            text = validationError ?: "",
                            color = WealthRed,
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.fillMaxWidth().testTag("dialog_error_text")
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    // Buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedButton(
                            onClick = onDismiss,
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("dialog_cancel_button"),
                            shape = RoundedCornerShape(8.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, WealthTextMuted)
                        ) {
                            Text("CANCEL", color = WealthTextPrimary, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = {
                                val amount = amountInput.toDoubleOrNull()
                                if (amount == null || amount <= 0) {
                                    validationError = "Validation Error: Amount must be greater than 0"
                                } else if (descriptionInput.isBlank()) {
                                    validationError = "Validation Error: Description cannot be empty"
                                } else if (selectedCategory.isBlank()) {
                                    validationError = "Validation Error: Category must be selected"
                                } else {
                                    onConfirm(amount, selectedCategory, descriptionInput, selectedType)
                                }
                            },
                            modifier = Modifier
                                .weight(1.5f)
                                .height(48.dp)
                                .testTag("dialog_submit_button"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = WealthGold,
                                contentColor = Color.Black
                            ),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("RECORD ENTRY", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    )
}
