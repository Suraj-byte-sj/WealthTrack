package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Search
import androidx.compose.ui.platform.LocalContext
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Transaction
import com.example.ui.theme.*
import com.example.util.CurrencyFormatter
import com.example.util.toCurrencyString
import com.example.viewmodel.WealthViewModel
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun TransactionsScreen(
    viewModel: WealthViewModel,
    modifier: Modifier = Modifier
) {
    val transactions by viewModel.transactions.collectAsState()
    val preferredLocale by viewModel.preferredLocale.collectAsState()
    val context = LocalContext.current

    var searchQuery by remember { mutableStateOf("") }
    var selectedTypeFilter by remember { mutableStateOf("All") }
    var selectedCategoryFilter by remember { mutableStateOf("All") }
    var selectedDatePreset by remember { mutableStateOf("All Time") }
    var startDate by remember { mutableStateOf<Long?>(null) }
    var endDate by remember { mutableStateOf<Long?>(null) }

    fun showDatePicker(initialTimestamp: Long, onDateSelected: (Long) -> Unit) {
        val cal = Calendar.getInstance().apply { timeInMillis = initialTimestamp }
        android.app.DatePickerDialog(
            context,
            { _, year, month, dayOfMonth ->
                val selectedCal = Calendar.getInstance().apply {
                    set(Calendar.YEAR, year)
                    set(Calendar.MONTH, month)
                    set(Calendar.DAY_OF_MONTH, dayOfMonth)
                }
                onDateSelected(selectedCal.timeInMillis)
            },
            cal.get(Calendar.YEAR),
            cal.get(Calendar.MONTH),
            cal.get(Calendar.DAY_OF_MONTH)
        ).show()
    }

    val filteredTransactions = remember(transactions, selectedTypeFilter, selectedCategoryFilter, searchQuery, selectedDatePreset, startDate, endDate) {
        transactions.filter { transaction ->
            val typeMatch = selectedTypeFilter == "All" || transaction.type.lowercase(Locale.ROOT) == selectedTypeFilter.lowercase(Locale.ROOT)
            val categoryMatch = selectedCategoryFilter == "All" || transaction.category.equals(selectedCategoryFilter, ignoreCase = true)
            
            val searchMatch = searchQuery.isEmpty() || 
                    transaction.description.contains(searchQuery, ignoreCase = true) ||
                    transaction.category.contains(searchQuery, ignoreCase = true)

            val dateMatch = when (selectedDatePreset) {
                "Today" -> {
                    val cal = Calendar.getInstance()
                    val todayYear = cal.get(Calendar.YEAR)
                    val todayDay = cal.get(Calendar.DAY_OF_YEAR)
                    
                    val transCal = Calendar.getInstance().apply { timeInMillis = transaction.date }
                    transCal.get(Calendar.YEAR) == todayYear && transCal.get(Calendar.DAY_OF_YEAR) == todayDay
                }
                "Last 7 Days" -> {
                    val sevenDaysAgo = Calendar.getInstance().apply {
                        add(Calendar.DAY_OF_YEAR, -7)
                        set(Calendar.HOUR_OF_DAY, 0)
                        set(Calendar.MINUTE, 0)
                        set(Calendar.SECOND, 0)
                        set(Calendar.MILLISECOND, 0)
                    }.timeInMillis
                    transaction.date >= sevenDaysAgo
                }
                "This Month" -> {
                    val cal = Calendar.getInstance()
                    val thisYear = cal.get(Calendar.YEAR)
                    val thisMonth = cal.get(Calendar.MONTH)
                    
                    val transCal = Calendar.getInstance().apply { timeInMillis = transaction.date }
                    transCal.get(Calendar.YEAR) == thisYear && transCal.get(Calendar.MONTH) == thisMonth
                }
                "Custom" -> {
                    val start = startDate ?: 0L
                    val end = endDate ?: Long.MAX_VALUE
                    transaction.date in start..end
                }
                else -> true // "All Time"
            }

            typeMatch && categoryMatch && searchMatch && dateMatch
        }
    }

    val categories = listOf("All", "Food", "Transport", "Shopping", "Bills", "Entertainment", "Others")

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(WealthDarkBg)
            .padding(horizontal = 16.dp)
    ) {
        Spacer(modifier = Modifier.height(16.dp))

        // Page Title
        Text(
            text = "TRANSACTION LEDGER",
            style = MaterialTheme.typography.labelMedium,
            color = WealthGold,
            letterSpacing = 2.sp,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "Capital Outbound & Inbound",
            style = MaterialTheme.typography.bodyLarge,
            color = WealthTextMuted,
            fontWeight = FontWeight.Light,
            modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
        )

        // Search Bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("Search description or category...", color = WealthTextMuted) },
            leadingIcon = {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = "Search Icon",
                    tint = WealthGold
                )
            },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(
                        onClick = { searchQuery = "" },
                        modifier = Modifier.testTag("search_clear_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Clear Search",
                            tint = WealthTextMuted
                        )
                    }
                }
            },
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = WealthTextPrimary,
                unfocusedTextColor = WealthTextPrimary,
                focusedContainerColor = WealthCardBg,
                unfocusedContainerColor = WealthCardBg,
                disabledContainerColor = WealthCardBg,
                focusedBorderColor = WealthGold,
                unfocusedBorderColor = Color.White.copy(alpha = 0.05f),
                cursorColor = WealthGold
            ),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp)
                .testTag("transaction_search_bar")
        )

        // Filters UI
        Card(
            colors = CardDefaults.cardColors(containerColor = WealthCardBg),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                // Type Filter Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("All", "Income", "Expense").forEach { type ->
                        FilterChip(
                            selected = selectedTypeFilter == type,
                            onClick = { selectedTypeFilter = type },
                            label = { Text(type) },
                            modifier = Modifier.weight(1f).testTag("filter_type_$type"),
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = WealthGold,
                                selectedLabelColor = Color.Black,
                                containerColor = Color.White.copy(alpha = 0.03f),
                                labelColor = WealthTextPrimary
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Date Preset Selector Title
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.CalendarMonth,
                        contentDescription = "Date icon",
                        tint = WealthGold,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Date Filter",
                        style = MaterialTheme.typography.labelSmall,
                        color = WealthTextMuted
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                val datePresets = listOf("All Time", "Today", "Last 7 Days", "This Month", "Custom")
                androidx.compose.foundation.lazy.LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(datePresets) { preset ->
                        val isSelected = selectedDatePreset == preset
                        Surface(
                            shape = RoundedCornerShape(50.dp),
                            color = if (isSelected) WealthGold.copy(alpha = 0.15f) else Color.White.copy(alpha = 0.03f),
                            border = if (isSelected) androidx.compose.foundation.BorderStroke(1.dp, WealthGold) else null,
                            modifier = Modifier
                                .clickable { selectedDatePreset = preset }
                                .testTag("filter_date_preset_$preset")
                        ) {
                            Text(
                                text = preset,
                                style = MaterialTheme.typography.labelSmall,
                                color = if (isSelected) WealthGold else WealthTextPrimary,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            )
                        }
                    }
                }

                if (selectedDatePreset == "Custom") {
                    Spacer(modifier = Modifier.height(10.dp))
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val formattedStart = startDate?.let { formatDate(it) } ?: "Select Start"
                        val formattedEnd = endDate?.let { formatDate(it) } ?: "Select End"
                        
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .background(Color.White.copy(alpha = 0.03f), RoundedCornerShape(8.dp))
                                .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(8.dp))
                                .clickable {
                                    showDatePicker(startDate ?: System.currentTimeMillis()) {
                                        val cal = Calendar.getInstance().apply {
                                            timeInMillis = it
                                            set(Calendar.HOUR_OF_DAY, 0)
                                            set(Calendar.MINUTE, 0)
                                            set(Calendar.SECOND, 0)
                                            set(Calendar.MILLISECOND, 0)
                                        }
                                        startDate = cal.timeInMillis
                                    }
                                }
                                .padding(vertical = 10.dp, horizontal = 12.dp)
                                .testTag("start_date_picker_button"),
                            contentAlignment = Alignment.CenterStart
                        ) {
                            Column {
                                Text("From", style = MaterialTheme.typography.labelSmall, color = WealthTextMuted)
                                Text(formattedStart, style = MaterialTheme.typography.bodyMedium, color = WealthTextPrimary, fontWeight = FontWeight.Bold)
                            }
                        }

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .background(Color.White.copy(alpha = 0.03f), RoundedCornerShape(8.dp))
                                .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(8.dp))
                                .clickable {
                                    showDatePicker(endDate ?: System.currentTimeMillis()) {
                                        val cal = Calendar.getInstance().apply {
                                            timeInMillis = it
                                            set(Calendar.HOUR_OF_DAY, 23)
                                            set(Calendar.MINUTE, 59)
                                            set(Calendar.SECOND, 59)
                                            set(Calendar.MILLISECOND, 999)
                                        }
                                        endDate = cal.timeInMillis
                                    }
                                }
                                .padding(vertical = 10.dp, horizontal = 12.dp)
                                .testTag("end_date_picker_button"),
                            contentAlignment = Alignment.CenterStart
                        ) {
                            Column {
                                Text("To", style = MaterialTheme.typography.labelSmall, color = WealthTextMuted)
                                Text(formattedEnd, style = MaterialTheme.typography.bodyMedium, color = WealthTextPrimary, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Scrollable Category Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.FilterList,
                        contentDescription = "Filter icon",
                        tint = WealthGold,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Category Filter",
                        style = MaterialTheme.typography.labelSmall,
                        color = WealthTextMuted
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                BoxWithConstraints {
                    androidx.compose.foundation.lazy.LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(categories) { cat ->
                            Surface(
                                shape = RoundedCornerShape(50.dp),
                                color = if (selectedCategoryFilter == cat) WealthGold.copy(alpha = 0.15f) else Color.White.copy(alpha = 0.03f),
                                border = if (selectedCategoryFilter == cat) androidx.compose.foundation.BorderStroke(1.dp, WealthGold) else null,
                                modifier = Modifier
                                    .clickable { selectedCategoryFilter = cat }
                                    .testTag("filter_category_$cat")
                            ) {
                                Text(
                                    text = cat,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (selectedCategoryFilter == cat) WealthGold else WealthTextPrimary,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Ledger List
        if (filteredTransactions.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.testTag("empty_state_view")
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = "No transactions",
                        tint = WealthTextMuted,
                        modifier = Modifier.size(48.dp)
                    )
                    Text(
                        text = "No transactions yet",
                        style = MaterialTheme.typography.bodyLarge,
                        color = WealthTextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Try clearing filters or add a new luxury transaction.",
                        style = MaterialTheme.typography.bodySmall,
                        color = WealthTextMuted,
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .testTag("transaction_lazy_column"),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 100.dp)
            ) {
                items(filteredTransactions, key = { it.id }) { item ->
                    TransactionItemCard(
                        transaction = item,
                        preferredLocale = preferredLocale,
                        onDeleteClick = { viewModel.deleteTransaction(item) }
                    )
                }
            }
        }
    }
}

@Composable
fun TransactionItemCard(
    transaction: Transaction,
    preferredLocale: CurrencyFormatter.CurrencyLocale,
    onDeleteClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isExpense = transaction.type == "expense"
    val colorSign = if (isExpense) "-" else "+"
    val signColor = if (isExpense) WealthRed else WealthGreen

    Card(
        colors = CardDefaults.cardColors(containerColor = WealthCardBg),
        shape = RoundedCornerShape(12.dp),
        modifier = modifier
            .fillMaxWidth()
            .testTag("transaction_item_${transaction.id}"),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(Color.White.copy(alpha = 0.04f)))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.weight(1.5f)
            ) {
                // Category Icon indicator
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .background(getCategoryColor(transaction.category).copy(alpha = 0.12f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .background(getCategoryColor(transaction.category), CircleShape)
                    )
                }

                Column {
                    Text(
                        text = transaction.description,
                        style = MaterialTheme.typography.bodyMedium,
                        color = WealthTextPrimary,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = transaction.category,
                            style = MaterialTheme.typography.labelSmall,
                            color = getCategoryColor(transaction.category),
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "•",
                            style = MaterialTheme.typography.labelSmall,
                            color = WealthTextMuted
                        )
                        Text(
                            text = formatDate(transaction.date),
                            style = MaterialTheme.typography.bodySmall,
                            color = WealthTextMuted
                        )
                    }
                }
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.weight(1f)
            ) {
                // Cash / Expense Indicator
                Spacer(modifier = Modifier.weight(1f))
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "$colorSign${transaction.amount.toCurrencyString(preferredLocale, includeDecimals = true)}",
                        style = MaterialTheme.typography.bodyLarge,
                        color = signColor,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.testTag("transaction_amount_${transaction.id}")
                    )
                }

                // Delete Button
                IconButton(
                    onClick = onDeleteClick,
                    modifier = Modifier
                        .size(36.dp)
                        .testTag("delete_button_${transaction.id}")
                ) {
                    Icon(
                        imageVector = Icons.Default.DeleteOutline,
                        contentDescription = "Delete transaction",
                        tint = WealthTextMuted.copy(alpha = 0.7f),
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

fun formatDate(timestamp: Long): String {
    val formatter = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault())
    return formatter.format(Date(timestamp))
}
