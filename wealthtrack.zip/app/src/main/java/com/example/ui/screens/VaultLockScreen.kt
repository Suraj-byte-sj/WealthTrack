package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Backspace
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.MainActivity
import com.example.ui.theme.*
import com.example.viewmodel.WealthViewModel

@Composable
fun VaultLockScreen(
    viewModel: WealthViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var pinInput by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    
    // Auto-trigger biometric on screen load
    LaunchedEffect(Unit) {
        val activity = context as? MainActivity
        activity?.authenticateBiometric(
            onSuccess = {
                viewModel.setUnlocked(true)
            },
            onError = { error ->
                errorMessage = "Biometrics unavailable or declined. Enter PIN fallback."
            }
        )
    }

    val triggerBiometric = {
        val activity = context as? MainActivity
        errorMessage = null
        activity?.authenticateBiometric(
            onSuccess = {
                viewModel.setUnlocked(true)
            },
            onError = { error ->
                errorMessage = error
            }
        )
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(WealthDarkBg)
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 450.dp)
        ) {
            // Header Shield / Lock
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(80.dp)
                    .background(WealthGold.copy(alpha = 0.1f), CircleShape)
                    .border(2.dp, WealthGold.copy(alpha = 0.3f), CircleShape)
            ) {
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = "Encrypted Ledger Lock",
                    tint = WealthGold,
                    modifier = Modifier.size(36.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "SOVEREIGN LEDGER VAULT",
                style = MaterialTheme.typography.titleMedium,
                color = WealthTextPrimary,
                fontWeight = FontWeight.Bold,
                letterSpacing = 2.sp,
                textAlign = TextAlign.Center
            )

            Text(
                text = "Your private asset balances are secure. Authenticate with biometrics or passcode to access the secure ledger.",
                style = MaterialTheme.typography.bodySmall,
                color = WealthTextMuted,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 24.dp)
            )

            // Biometric Primary Action Button
            Button(
                onClick = { triggerBiometric() },
                colors = ButtonDefaults.buttonColors(
                    containerColor = WealthGold,
                    contentColor = Color.Black
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("biometric_unlock_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Fingerprint,
                    contentDescription = null,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "BIOMETRIC UNLOCK",
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            // PIN Indicator Dots
            Row(
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(vertical = 12.dp)
            ) {
                repeat(4) { index ->
                    val isFilled = index < pinInput.length
                    Box(
                        modifier = Modifier
                            .size(14.dp)
                            .background(
                                if (isFilled) WealthGold else Color.White.copy(alpha = 0.1f),
                                CircleShape
                            )
                            .border(
                                1.dp,
                                if (isFilled) WealthGold else Color.White.copy(alpha = 0.2f),
                                CircleShape
                            )
                    )
                }
            }

            // Error Message
            errorMessage?.let { msg ->
                Text(
                    text = msg,
                    color = WealthRed,
                    style = MaterialTheme.typography.labelSmall,
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .padding(vertical = 8.dp)
                        .testTag("biometric_error_text")
                )
            } ?: Spacer(modifier = Modifier.height(24.dp))

            // Custom Keypad
            Column(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth(0.85f)
            ) {
                val keys = listOf(
                    listOf("1", "2", "3"),
                    listOf("4", "5", "6"),
                    listOf("7", "8", "9"),
                    listOf("Bypass", "0", "Back")
                )

                keys.forEach { row ->
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        row.forEach { key ->
                            val isSpecial = key == "Bypass" || key == "Back"
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier
                                    .weight(1f)
                                    .aspectRatio(1.6f)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(
                                        if (isSpecial) Color.White.copy(alpha = 0.03f) else WealthCardBg
                                    )
                                    .border(
                                        1.dp,
                                        if (isSpecial) Color.White.copy(alpha = 0.05f) else Color.White.copy(alpha = 0.08f),
                                        RoundedCornerShape(12.dp)
                                    )
                                    .clickable {
                                        when (key) {
                                            "Bypass" -> {
                                                // Quick demo unlock bypass
                                                viewModel.setUnlocked(true)
                                            }
                                            "Back" -> {
                                                if (pinInput.isNotEmpty()) {
                                                    pinInput = pinInput.dropLast(1)
                                                    errorMessage = null
                                                }
                                            }
                                            else -> {
                                                if (pinInput.length < 4) {
                                                    pinInput += key
                                                    errorMessage = null
                                                    
                                                    // Auto-verify when 4 characters entered
                                                    if (pinInput.length == 4) {
                                                        if (pinInput == "0000") {
                                                            viewModel.setUnlocked(true)
                                                        } else {
                                                            errorMessage = "Incorrect Passcode. Try '0000' or use Bypass."
                                                            pinInput = ""
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    .testTag("keypad_button_$key")
                            ) {
                                if (key == "Back") {
                                    Icon(
                                        imageVector = Icons.Default.Backspace,
                                        contentDescription = "Backspace",
                                        tint = WealthTextMuted,
                                        modifier = Modifier.size(20.dp)
                                    )
                                } else {
                                    Text(
                                        text = key,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = if (key == "Bypass") WealthGold else WealthTextPrimary,
                                        fontSize = if (key == "Bypass") 12.sp else 18.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
