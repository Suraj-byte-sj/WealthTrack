package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.util.CurrencyFormatter
import com.example.viewmodel.WealthViewModel

@Composable
fun ProfileScreen(
    viewModel: WealthViewModel,
    modifier: Modifier = Modifier
) {
    val budgetGoal by viewModel.budgetGoal.collectAsState()
    val preferredLocale by viewModel.preferredLocale.collectAsState()
    val biometricLockEnabled by viewModel.biometricLockEnabled.collectAsState()

    var budgetInput by remember { mutableStateOf("") }
    var budgetError by remember { mutableStateOf<String?>(null) }
    var showDialog by remember { mutableStateOf(false) }

    LaunchedEffect(budgetGoal) {
        budgetInput = budgetGoal.toLong().toString()
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(WealthDarkBg)
            .padding(horizontal = 16.dp)
    ) {
        Spacer(modifier = Modifier.height(16.dp))

        // Page Header
        Text(
            text = "SOVEREIGN ACCOUNT",
            style = MaterialTheme.typography.labelMedium,
            color = WealthGold,
            letterSpacing = 2.sp,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "Credentials & Custom Configurations",
            style = MaterialTheme.typography.bodyLarge,
            color = WealthTextMuted,
            fontWeight = FontWeight.Light,
            modifier = Modifier.padding(top = 4.dp, bottom = 20.dp)
        )

        // Custom Profile Card with Sovereign Visuals
        Card(
            colors = CardDefaults.cardColors(containerColor = WealthCardBg),
            shape = RoundedCornerShape(16.dp),
            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(WealthGold.copy(alpha = 0.15f))),
            modifier = Modifier.fillMaxWidth().testTag("sovereign_profile_card")
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Gold-ring avatar placeholder
                Box(
                    modifier = Modifier
                        .size(72.dp)
                        .clip(CircleShape)
                        .background(WealthDarkBg)
                        .border(1.5.dp, WealthGold, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "SV",
                        style = MaterialTheme.typography.headlineSmall,
                        color = WealthGold,
                        fontWeight = FontWeight.Light,
                        fontFamily = FontFamily.SansSerif
                    )
                }

                Column {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "Sovereign Apex",
                            style = MaterialTheme.typography.titleLarge,
                            color = WealthTextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                        Icon(
                            imageVector = Icons.Default.WorkspacePremium,
                            contentDescription = "Apex Level Verified",
                            tint = WealthGold,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Text(
                        text = "Tier Level: Archon Multi-Asset",
                        style = MaterialTheme.typography.bodySmall,
                        color = WealthGold
                    )
                    Text(
                        text = "Encrypted Vault Active",
                        style = MaterialTheme.typography.bodySmall,
                        color = WealthTextMuted
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // SharedPreferences Configuration Card
        Card(
            colors = CardDefaults.cardColors(containerColor = WealthCardBg),
            shape = RoundedCornerShape(16.dp),
            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(Color.White.copy(alpha = 0.05f))),
            modifier = Modifier.fillMaxWidth().testTag("budget_goal_configuration_card")
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = "CEILING BUDGET SETTINGS",
                    style = MaterialTheme.typography.titleSmall,
                    color = WealthTextMuted,
                    letterSpacing = 1.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = "Determine the monthly spending limit for insights checking.",
                    style = MaterialTheme.typography.bodySmall,
                    color = WealthTextMuted,
                    modifier = Modifier.padding(top = 4.dp, bottom = 16.dp)
                )

                // Filled Textfield
                TextField(
                    value = budgetInput,
                    onValueChange = {
                        budgetInput = it
                        budgetError = null
                    },
                    label = { Text("Monthly Budget Goal (USD)") },
                    isError = budgetError != null,
                    supportingText = {
                        if (budgetError != null) {
                            Text(text = budgetError ?: "", color = WealthRed)
                        } else {
                            Text("Stored inside Local SharedPreferences securely.")
                        }
                    },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = WealthDarkBg,
                        unfocusedContainerColor = WealthDarkBg,
                        focusedLabelColor = WealthGold,
                        unfocusedLabelColor = WealthTextMuted,
                        focusedIndicatorColor = WealthGold,
                        unfocusedIndicatorColor = Color.Transparent,
                        errorContainerColor = WealthDarkBg
                    ),
                    modifier = Modifier.fillMaxWidth().testTag("budget_goal_input"),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Save button
                Button(
                    onClick = {
                        val parsed = budgetInput.toDoubleOrNull()
                        if (parsed == null || parsed <= 0) {
                            budgetError = "Ceiling amount must be greater than 0"
                        } else {
                            viewModel.updateBudgetGoal(parsed)
                        }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = WealthGold,
                        contentColor = Color.Black
                    ),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth().height(48.dp).testTag("save_budget_button")
                ) {
                    Text(
                        text = "SAVE CEILING CONFIGURATION",
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.5.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Preferred Currency Selection Card
        Card(
            colors = CardDefaults.cardColors(containerColor = WealthCardBg),
            shape = RoundedCornerShape(16.dp),
            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(Color.White.copy(alpha = 0.05f))),
            modifier = Modifier.fillMaxWidth().testTag("currency_selection_card")
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = "CURRENCY LOCALE SETTINGS",
                    style = MaterialTheme.typography.titleSmall,
                    color = WealthTextMuted,
                    letterSpacing = 1.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = "Select your preferred country or region to format financial figures across the ledger.",
                    style = MaterialTheme.typography.bodySmall,
                    color = WealthTextMuted,
                    modifier = Modifier.padding(top = 4.dp, bottom = 16.dp)
                )

                // Current Preference Row (Clickable to change)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { showDialog = true }
                        .background(WealthDarkBg, RoundedCornerShape(8.dp))
                        .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(8.dp))
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Active Configuration",
                            style = MaterialTheme.typography.labelSmall,
                            color = WealthGold
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = preferredLocale.displayName,
                            style = MaterialTheme.typography.bodyMedium,
                            color = WealthTextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Box(
                        modifier = Modifier
                            .background(WealthGold.copy(alpha = 0.12f), RoundedCornerShape(6.dp))
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = "CHANGE",
                            style = MaterialTheme.typography.labelSmall,
                            color = WealthGold,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        if (showDialog) {
            AlertDialog(
                onDismissRequest = { showDialog = false },
                title = { Text("Select Region & Currency", color = WealthGold) },
                text = {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        CurrencyFormatter.CurrencyLocale.values().forEach { loc ->
                            val isSelected = loc == preferredLocale
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        viewModel.updatePreferredLocale(loc)
                                        showDialog = false
                                    }
                                    .background(
                                        if (isSelected) WealthGold.copy(alpha = 0.15f) else Color.Transparent,
                                        RoundedCornerShape(8.dp)
                                    )
                                    .border(
                                        1.dp,
                                        if (isSelected) WealthGold else Color.White.copy(alpha = 0.05f),
                                        RoundedCornerShape(8.dp)
                                    )
                                    .padding(horizontal = 16.dp, vertical = 12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = loc.displayName,
                                        color = if (isSelected) WealthGold else WealthTextPrimary,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        style = MaterialTheme.typography.bodyMedium
                                    )
                                }
                                Text(
                                    text = loc.symbol,
                                    color = if (isSelected) WealthGold else WealthTextMuted,
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.titleMedium
                                )
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showDialog = false }) {
                        Text("CLOSE", color = WealthGold)
                    }
                },
                containerColor = WealthCardBg,
                shape = RoundedCornerShape(16.dp)
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Biometric Security Lock Card
        Card(
            colors = CardDefaults.cardColors(containerColor = WealthCardBg),
            shape = RoundedCornerShape(16.dp),
            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(Color.White.copy(alpha = 0.05f))),
            modifier = Modifier.fillMaxWidth().testTag("biometric_security_card")
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = "SECURITY SETTINGS",
                    style = MaterialTheme.typography.titleSmall,
                    color = WealthTextMuted,
                    letterSpacing = 1.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = "Require fingerprint or facial biometric authentication to access and display financial figures across your ledger.",
                    style = MaterialTheme.typography.bodySmall,
                    color = WealthTextMuted,
                    modifier = Modifier.padding(top = 4.dp, bottom = 16.dp)
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(WealthDarkBg, RoundedCornerShape(8.dp))
                        .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(8.dp))
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Biometric Lock",
                            style = MaterialTheme.typography.bodyMedium,
                            color = WealthTextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = if (biometricLockEnabled) "Enabled (Secure Mode)" else "Disabled (No protection)",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (biometricLockEnabled) WealthGold else WealthTextMuted
                        )
                    }
                    Switch(
                        checked = biometricLockEnabled,
                        onCheckedChange = { isChecked ->
                            viewModel.updateBiometricLockEnabled(isChecked)
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.Black,
                            checkedTrackColor = WealthGold,
                            uncheckedThumbColor = WealthTextMuted,
                            uncheckedTrackColor = Color.White.copy(alpha = 0.05f)
                        ),
                        modifier = Modifier.testTag("biometric_lock_switch")
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Reset / Seed Options Card
        Card(
            colors = CardDefaults.cardColors(containerColor = WealthCardBg),
            shape = RoundedCornerShape(16.dp),
            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(Color.White.copy(alpha = 0.05f))),
            modifier = Modifier.fillMaxWidth().testTag("database_reset_card")
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = "VAULT UTILITIES",
                    style = MaterialTheme.typography.titleSmall,
                    color = WealthTextMuted,
                    letterSpacing = 1.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = "Reset all ledger contents and investments to the default seeded luxury states.",
                    style = MaterialTheme.typography.bodySmall,
                    color = WealthTextMuted,
                    modifier = Modifier.padding(top = 4.dp, bottom = 16.dp)
                )

                Button(
                    onClick = { viewModel.resetDatabase() },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color.Transparent,
                        contentColor = WealthGold
                    ),
                    shape = RoundedCornerShape(8.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, WealthGold),
                    modifier = Modifier.fillMaxWidth().height(48.dp).testTag("reset_database_button")
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Reset Icon"
                        )
                        Text(
                            text = "RESET VAULT LEDGER",
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.5.sp
                        )
                    }
                }
            }
        }
    }
}
