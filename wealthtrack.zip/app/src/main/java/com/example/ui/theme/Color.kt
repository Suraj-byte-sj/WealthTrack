package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

// Luxury Minimalist Palette
val WealthGold = Color(0xFFFFD700)      // Premium Gold Accent
val WealthDarkGold = Color(0xFFC5A300)  // Darker Gold Accent
val WealthDarkBg = Color(0xFF0C0E14)    // Extremely dark canvas background
val WealthCardBg = Color(0xFF161A24)    // Elevated, rich dark surface
val WealthTextPrimary = Color(0xFFF1F5F9) // Clean slate white text
val WealthTextMuted = Color(0xFF94A3B8)   // Slate muted gray text
val WealthGreen = Color(0xFF10B981)       // Modern emerald green for profits
val WealthRed = Color(0xFFEF4444)         // Modern coral red for losses

// Spending Categories Colors
val CategoryFood = Color(0xFFF97316)          // Orange
val CategoryTransport = Color(0xFF3B82F6)     // Blue
val CategoryShopping = Color(0xFFA855F7)      // Purple
val CategoryBills = Color(0xFF10B981)         // Emerald
val CategoryEntertainment = Color(0xFFEC4899) // Pink
val CategoryOthers = Color(0xFFEAB308)        // Golden Yellow
