package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.util.CurrencyFormatter
import com.example.util.toCurrencyString
import com.example.viewmodel.WealthViewModel

@Composable
fun ReportsScreen(
    viewModel: WealthViewModel,
    modifier: Modifier = Modifier
) {
    val transactions by viewModel.transactions.collectAsState()
    val investments by viewModel.investments.collectAsState()
    val budgetGoal by viewModel.budgetGoal.collectAsState()
    val baseCash by viewModel.baseCash.collectAsState()
    val baseLiabilities by viewModel.baseLiabilities.collectAsState()
    val preferredLocale by viewModel.preferredLocale.collectAsState()

    val totalIncomes = remember(transactions) {
        transactions.filter { it.type == "income" }.sumOf { it.amount }
    }
    val totalExpenses = remember(transactions) {
        transactions.filter { it.type == "expense" }.sumOf { it.amount }
    }
    val currentInvestmentsValue = remember(investments) {
        investments.sumOf { it.currentValue }
    }

    val liquidCash = baseCash + totalIncomes - totalExpenses
    val totalAssets = liquidCash + currentInvestmentsValue
    val totalLiabilities = baseLiabilities

    val netWorth = totalAssets - totalLiabilities

    // Category breakdown totals
    val categoryTotals = remember(transactions) {
        val list = listOf("Food", "Transport", "Shopping", "Bills", "Entertainment", "Others")
        list.map { cat ->
            val amt = transactions.filter { it.type == "expense" && it.category == cat }.sumOf { it.amount }
            cat to amt
        }.filter { it.second > 0 }.sortedByDescending { it.second }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(WealthDarkBg)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 100.dp)
    ) {
        // Header
        item {
            Column {
                Text(
                    text = "FINANCIAL ANALYTICS",
                    style = MaterialTheme.typography.labelMedium,
                    color = WealthGold,
                    letterSpacing = 2.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Allocation & Budget Performance",
                    style = MaterialTheme.typography.bodyLarge,
                    color = WealthTextMuted,
                    fontWeight = FontWeight.Light,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        }

        // Budget Goal performance (SharedPreferences)
        item {
            val budgetSpentRatio = if (budgetGoal > 0) (totalExpenses / budgetGoal).toFloat() else 0f
            val budgetRemaining = maxOf(0.0, budgetGoal - totalExpenses)

            Card(
                colors = CardDefaults.cardColors(containerColor = WealthCardBg),
                shape = RoundedCornerShape(16.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(Color.White.copy(alpha = 0.05f))),
                modifier = Modifier.fillMaxWidth().testTag("budget_performance_card")
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "BUDGET OVERVIEW (SHARED PREFS)",
                        style = MaterialTheme.typography.titleSmall,
                        color = WealthTextMuted,
                        letterSpacing = 1.sp,
                        fontWeight = FontWeight.SemiBold
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Bottom
                    ) {
                        Column {
                            Text(
                                text = "Monthly Ceiling Limit",
                                style = MaterialTheme.typography.bodySmall,
                                color = WealthTextMuted
                            )
                            Text(
                                text = budgetGoal.toCurrencyString(preferredLocale, includeDecimals = false),
                                style = MaterialTheme.typography.titleLarge,
                                color = WealthGold,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "Spent to Date",
                                style = MaterialTheme.typography.bodySmall,
                                color = WealthTextMuted
                            )
                            Text(
                                text = totalExpenses.toCurrencyString(preferredLocale, includeDecimals = true),
                                style = MaterialTheme.typography.titleMedium,
                                color = WealthTextPrimary,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Progress bar
                    LinearProgressIndicator(
                        progress = { minOf(1.0f, budgetSpentRatio) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(10.dp)
                            .testTag("budget_progress_bar"),
                        color = if (budgetSpentRatio > 0.8) WealthRed else WealthGold,
                        trackColor = Color.White.copy(alpha = 0.08f),
                        strokeCap = StrokeCap.Round,
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "${String.format("%.1f", budgetSpentRatio * 100)}% Spent",
                            style = MaterialTheme.typography.bodySmall,
                            color = if (budgetSpentRatio > 0.8) WealthRed else WealthTextMuted,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Remaining: ${budgetRemaining.toCurrencyString(preferredLocale, includeDecimals = false)}",
                            style = MaterialTheme.typography.bodySmall,
                            color = WealthGreen,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Net Worth Distribution Details (Real vs Liquid Assets)
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = WealthCardBg),
                shape = RoundedCornerShape(16.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(Color.White.copy(alpha = 0.05f))),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "PORTFOLIO ALLOCATION",
                        style = MaterialTheme.typography.titleSmall,
                        color = WealthTextMuted,
                        letterSpacing = 1.sp,
                        fontWeight = FontWeight.SemiBold
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        // Liquid Assets Card
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.02f)),
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = "LIQUID CAPITAL",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = WealthTextMuted
                                )
                                Text(
                                    text = liquidCash.toCurrencyString(preferredLocale, includeDecimals = false),
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = WealthTextPrimary,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "${String.format("%.1f", (liquidCash / totalAssets) * 100)}% of total",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = WealthTextMuted
                                )
                            }
                        }

                        // Investments Card
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.02f)),
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = "INVESTMENTS",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = WealthTextMuted
                                )
                                Text(
                                    text = currentInvestmentsValue.toCurrencyString(preferredLocale, includeDecimals = false),
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = WealthTextPrimary,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "${String.format("%.1f", (currentInvestmentsValue / totalAssets) * 100)}% of total",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = WealthTextMuted
                                )
                            }
                        }
                    }
                }
            }
        }

        // Category breakdown table
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = WealthCardBg),
                shape = RoundedCornerShape(16.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(Color.White.copy(alpha = 0.05f))),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "OUTBOUND CATEGORY INSIGHTS",
                        style = MaterialTheme.typography.titleSmall,
                        color = WealthTextMuted,
                        letterSpacing = 1.sp,
                        fontWeight = FontWeight.SemiBold
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    if (categoryTotals.isEmpty()) {
                        Text(
                            text = "No recorded categories yet.",
                            color = WealthTextMuted,
                            modifier = Modifier.padding(vertical = 12.dp)
                        )
                    } else {
                        // Headers
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Category", style = MaterialTheme.typography.labelSmall, color = WealthTextMuted, modifier = Modifier.weight(1.5f))
                            Text("Total Outlay", style = MaterialTheme.typography.labelSmall, color = WealthTextMuted, modifier = Modifier.weight(1.2f), textAlign = TextAlign.End)
                            Text("Ratio", style = MaterialTheme.typography.labelSmall, color = WealthTextMuted, modifier = Modifier.weight(1f), textAlign = TextAlign.End)
                        }

                        categoryTotals.forEach { (cat, amount) ->
                            val percent = (amount / totalExpenses) * 100
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    modifier = Modifier.weight(1.5f)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(8.dp)
                                            .background(getCategoryColor(cat), RoundedCornerShape(50.dp))
                                    )
                                    Text(
                                        text = cat,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = WealthTextPrimary,
                                        fontWeight = FontWeight.Bold
                                    )
                                }

                                Text(
                                    text = amount.toCurrencyString(preferredLocale, includeDecimals = true),
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = WealthTextPrimary,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.weight(1.2f),
                                    textAlign = TextAlign.End
                                )

                                Text(
                                    text = "${String.format("%.1f", percent)}%",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = WealthTextMuted,
                                    modifier = Modifier.weight(1f),
                                    textAlign = TextAlign.End
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
