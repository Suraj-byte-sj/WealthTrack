package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = WealthGold,
    onPrimary = Color(0xFF0C0E14),
    secondary = WealthDarkGold,
    onSecondary = Color(0xFF0C0E14),
    background = WealthDarkBg,
    onBackground = WealthTextPrimary,
    surface = WealthCardBg,
    onSurface = WealthTextPrimary,
    surfaceVariant = Color(0xFF1E2330),
    onSurfaceVariant = WealthTextMuted,
    error = WealthRed,
    onError = Color.White
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Force premium dark theme by default as requested
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}
