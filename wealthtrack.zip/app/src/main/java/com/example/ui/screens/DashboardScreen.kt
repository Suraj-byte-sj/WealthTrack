package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Investment
import com.example.data.model.InvestmentAlert
import com.example.data.model.Transaction
import com.example.ui.theme.*
import com.example.util.CurrencyFormatter
import com.example.util.toCurrencyString
import com.example.viewmodel.WealthViewModel

@Composable
fun DashboardScreen(
    viewModel: WealthViewModel,
    modifier: Modifier = Modifier
) {
    val transactions by viewModel.transactions.collectAsState()
    val investments by viewModel.investments.collectAsState()
    val budgetGoal by viewModel.budgetGoal.collectAsState()
    val baseCash by viewModel.baseCash.collectAsState()
    val baseLiabilities by viewModel.baseLiabilities.collectAsState()
    val preferredLocale by viewModel.preferredLocale.collectAsState()

    var selectedInvestmentForAlert by remember { mutableStateOf<Investment?>(null) }

    // Derived states for mathematical calculations
    val totalIncomes = remember(transactions) {
        transactions.filter { it.type == "income" }.sumOf { it.amount }
    }
    val totalExpenses = remember(transactions) {
        transactions.filter { it.type == "expense" }.sumOf { it.amount }
    }
    val totalInvested = remember(investments) {
        investments.sumOf { it.amountInvested }
    }
    val currentInvestmentsValue = remember(investments) {
        investments.sumOf { it.currentValue }
    }

    val liquidCash = baseCash + totalIncomes - totalExpenses
    val totalAssets = liquidCash + currentInvestmentsValue
    val totalLiabilities = baseLiabilities

    val netWorth = totalAssets - totalLiabilities

    // Profit percentage for investments
    val investmentProfitPercent = if (totalInvested > 0) {
        ((currentInvestmentsValue - totalInvested) / totalInvested) * 100
    } else {
        0.0
    }

    // Spending category breakdown
    val categoryTotals = remember(transactions) {
        val map = mutableMapOf(
            "Food" to 0.0,
            "Transport" to 0.0,
            "Shopping" to 0.0,
            "Bills" to 0.0,
            "Entertainment" to 0.0,
            "Others" to 0.0
        )
        transactions.filter { it.type == "expense" }.forEach {
            map[it.category] = (map[it.category] ?: 0.0) + it.amount
        }
        map.toList().filter { it.second > 0 }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(WealthDarkBg)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 100.dp)
    ) {
        // Welcome and Header
        item {
            Column(modifier = Modifier.padding(vertical = 8.dp)) {
                Text(
                    text = "WEALTH_TRACK",
                    style = MaterialTheme.typography.labelMedium,
                    color = WealthGold,
                    letterSpacing = 2.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Welcome Back, Sovereign",
                    style = MaterialTheme.typography.headlineMedium,
                    color = WealthTextPrimary,
                    fontWeight = FontWeight.Light,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        }

        // Card 1: Total Net Worth
        item {
            NetWorthCard(
                netWorth = netWorth,
                assets = totalAssets,
                liabilities = totalLiabilities,
                liquidCash = liquidCash,
                investmentsValue = currentInvestmentsValue,
                preferredLocale = preferredLocale
            )
        }

        // Card 2: Spending Breakdown (Pie / Doughnut Chart)
        item {
            SpendingBreakdownCard(
                totalExpenses = totalExpenses,
                categoryTotals = categoryTotals,
                preferredLocale = preferredLocale
            )
        }

        // Card 3: Top Investments
        item {
            InvestmentsCard(
                investments = investments.take(5),
                totalInvested = totalInvested,
                currentValue = currentInvestmentsValue,
                profitPercent = investmentProfitPercent,
                preferredLocale = preferredLocale,
                onInvestmentClick = { selectedInvestmentForAlert = it }
            )
        }

        // Card 4: Price Threshold Alerts Controller
        item {
            PriceAlertsCard(viewModel = viewModel)
        }

        // Card 5: AI Insight Feed
        item {
            AiInsightFeedCard(
                transactions = transactions,
                investments = investments,
                budgetGoal = budgetGoal,
                totalExpenses = totalExpenses,
                investmentProfitPercent = investmentProfitPercent,
                preferredLocale = preferredLocale
            )
        }
    }

    if (selectedInvestmentForAlert != null) {
        ManageAlertsDialog(
            investment = selectedInvestmentForAlert!!,
            viewModel = viewModel,
            onDismiss = { selectedInvestmentForAlert = null }
        )
    }
}

@Composable
fun NetWorthCard(
    netWorth: Double,
    assets: Double,
    liabilities: Double,
    liquidCash: Double,
    investmentsValue: Double,
    preferredLocale: CurrencyFormatter.CurrencyLocale,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("net_worth_card"),
        colors = CardDefaults.cardColors(containerColor = WealthCardBg),
        shape = RoundedCornerShape(16.dp),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(WealthGold.copy(alpha = 0.15f)))
    ) {
        Column(
            modifier = Modifier.padding(20.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "TOTAL NET WORTH",
                    style = MaterialTheme.typography.titleSmall,
                    color = WealthTextMuted,
                    letterSpacing = 1.sp,
                    fontWeight = FontWeight.SemiBold
                )
                // Trending Badge
                Surface(
                    shape = RoundedCornerShape(50.dp),
                    color = WealthGreen.copy(alpha = 0.12f),
                    modifier = Modifier.testTag("net_worth_trending_badge")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ArrowUpward,
                            contentDescription = "Trending Up",
                            tint = WealthGreen,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = "+4.2% MoM",
                            style = MaterialTheme.typography.labelSmall,
                            color = WealthGreen,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Main Net Worth Display
            Text(
                text = netWorth.toCurrencyString(preferredLocale, includeDecimals = false),
                style = MaterialTheme.typography.displayMedium,
                color = WealthGold,
                fontFamily = FontFamily.SansSerif,
                fontWeight = FontWeight.ExtraLight,
                modifier = Modifier.testTag("net_worth_amount_text")
            )

            HorizontalDivider(
                modifier = Modifier.padding(vertical = 16.dp),
                color = Color.White.copy(alpha = 0.08f)
            )

            // Assets vs Liabilities Sub-Breakdown
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "TOTAL ASSETS",
                        style = MaterialTheme.typography.labelSmall,
                        color = WealthTextMuted,
                        letterSpacing = 0.5.sp
                    )
                    Text(
                        text = assets.toCurrencyString(preferredLocale, includeDecimals = false),
                        style = MaterialTheme.typography.bodyLarge,
                        color = WealthTextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Cash: ${liquidCash.toCurrencyString(preferredLocale, includeDecimals = false)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = WealthTextMuted
                    )
                    Text(
                        text = "Invest: ${investmentsValue.toCurrencyString(preferredLocale, includeDecimals = false)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = WealthTextMuted
                    )
                }

                VerticalDivider(
                    modifier = Modifier.height(60.dp),
                    color = Color.White.copy(alpha = 0.08f)
                )

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "TOTAL LIABILITIES",
                        style = MaterialTheme.typography.labelSmall,
                        color = WealthTextMuted,
                        letterSpacing = 0.5.sp
                    )
                    Text(
                        text = liabilities.toCurrencyString(preferredLocale, includeDecimals = false),
                        style = MaterialTheme.typography.bodyLarge,
                        color = WealthRed,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Lines of Credit",
                        style = MaterialTheme.typography.bodySmall,
                        color = WealthTextMuted
                    )
                    Text(
                        text = "Villa Mortgages",
                        style = MaterialTheme.typography.bodySmall,
                        color = WealthTextMuted
                    )
                }
            }
        }
    }
}

@Composable
fun SpendingBreakdownCard(
    totalExpenses: Double,
    categoryTotals: List<Pair<String, Double>>,
    preferredLocale: CurrencyFormatter.CurrencyLocale,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("spending_pie_chart"),
        colors = CardDefaults.cardColors(containerColor = WealthCardBg),
        shape = RoundedCornerShape(16.dp),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(Color.White.copy(alpha = 0.05f)))
    ) {
        Column(
            modifier = Modifier.padding(20.dp)
        ) {
            Text(
                text = "MONTHLY SPENDING BREAKDOWN",
                style = MaterialTheme.typography.titleSmall,
                color = WealthTextMuted,
                letterSpacing = 1.sp,
                fontWeight = FontWeight.SemiBold
            )

            Spacer(modifier = Modifier.height(20.dp))

            if (categoryTotals.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("No expenses recorded yet", color = WealthTextMuted, style = MaterialTheme.typography.bodyMedium)
                        Text("Create a transaction to populate chart", color = WealthTextMuted.copy(alpha = 0.6f), style = MaterialTheme.typography.bodySmall)
                    }
                }
            } else {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Custom Donut / Pie Chart using Compose Canvas
                    Box(
                        modifier = Modifier
                            .size(150.dp)
                            .weight(1f),
                        contentAlignment = Alignment.Center
                    ) {
                        val donutThickness = with(LocalDensity.current) { 14.dp.toPx() }

                        Canvas(modifier = Modifier.size(130.dp)) {
                            var startAngle = -90f
                            categoryTotals.forEach { (cat, amount) ->
                                val sweepAngle = ((amount / totalExpenses) * 360f).toFloat()
                                drawArc(
                                    color = getCategoryColor(cat),
                                    startAngle = startAngle,
                                    sweepAngle = sweepAngle,
                                    useCenter = false,
                                    style = Stroke(width = donutThickness, cap = StrokeCap.Round)
                                )
                                startAngle += sweepAngle
                            }
                        }

                        // Center Text showing total
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "TOTAL",
                                style = MaterialTheme.typography.labelSmall,
                                color = WealthTextMuted,
                                letterSpacing = 1.sp
                            )
                            Text(
                                text = totalExpenses.toCurrencyString(preferredLocale, includeDecimals = false),
                                style = MaterialTheme.typography.titleMedium,
                                color = WealthTextPrimary,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    // Side Legend
                    Column(
                        modifier = Modifier.weight(1.2f),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        categoryTotals.forEach { (cat, amount) ->
                            val percent = (amount / totalExpenses) * 100
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(10.dp)
                                            .background(getCategoryColor(cat), CircleShape)
                                    )
                                    Text(
                                        text = cat,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = WealthTextPrimary,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                Text(
                                    text = "${String.format("%.1f", percent)}%",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = WealthTextMuted,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun InvestmentsCard(
    investments: List<Investment>,
    totalInvested: Double,
    currentValue: Double,
    profitPercent: Double,
    preferredLocale: CurrencyFormatter.CurrencyLocale,
    onInvestmentClick: (Investment) -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("investments_list"),
        colors = CardDefaults.cardColors(containerColor = WealthCardBg),
        shape = RoundedCornerShape(16.dp),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(Color.White.copy(alpha = 0.05f)))
    ) {
        Column(
            modifier = Modifier.padding(20.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "TOP INVESTMENTS",
                        style = MaterialTheme.typography.titleSmall,
                        color = WealthTextMuted,
                        letterSpacing = 1.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "Tap asset to set threshold alert",
                        style = MaterialTheme.typography.bodySmall,
                        color = WealthGold,
                        fontWeight = FontWeight.Medium
                    )
                }

                // Profit Display
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = currentValue.toCurrencyString(preferredLocale, includeDecimals = false),
                        style = MaterialTheme.typography.bodyLarge,
                        color = WealthGold,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "+${String.format("%.2f", profitPercent)}% ROI",
                        style = MaterialTheme.typography.bodySmall,
                        color = WealthGreen,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (investments.isEmpty()) {
                Text("No investments available", color = WealthTextMuted, modifier = Modifier.padding(vertical = 12.dp))
            } else {
                Column(
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    investments.forEach { inv ->
                        val singleProfit = ((inv.currentValue - inv.amountInvested) / inv.amountInvested) * 100
                        val profitColor = if (singleProfit >= 0) WealthGreen else WealthRed
                        val profitSign = if (singleProfit >= 0) "+" else ""

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color.White.copy(alpha = 0.02f), RoundedCornerShape(8.dp))
                                .clickable { onInvestmentClick(inv) }
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1.5f)) {
                                Text(
                                    text = inv.name,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = WealthTextPrimary,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "Purchased: ${inv.purchaseDate}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = WealthTextMuted
                                )
                            }

                            Column(
                                modifier = Modifier.weight(1f),
                                horizontalAlignment = Alignment.End
                            ) {
                                Text(
                                    text = inv.currentValue.toCurrencyString(preferredLocale, includeDecimals = false),
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = WealthTextPrimary,
                                    fontWeight = FontWeight.Bold
                                )
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = profitColor.copy(alpha = 0.12f)
                                ) {
                                    Text(
                                        text = "$profitSign${String.format("%.1f", singleProfit)}%",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = profitColor,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AiInsightFeedCard(
    transactions: List<Transaction>,
    investments: List<Investment>,
    budgetGoal: Double,
    totalExpenses: Double,
    investmentProfitPercent: Double,
    preferredLocale: CurrencyFormatter.CurrencyLocale,
    modifier: Modifier = Modifier
) {
    val insights = remember(transactions, investments, budgetGoal, totalExpenses, investmentProfitPercent, preferredLocale) {
        val list = mutableListOf<String>()

        val formattedBudget = budgetGoal.toCurrencyString(preferredLocale, includeDecimals = false)

        // Insight 1: Spending Ratio / Budget Warnings
        val ratio = if (budgetGoal > 0) (totalExpenses / budgetGoal) * 100 else 0.0
        if (ratio > 80) {
            list.add("Sovereign, your monthly spending has reached ${String.format("%.0f", ratio)}% of your designated luxury ceiling budget of $formattedBudget. Capital preservation modes are advised.")
        } else if (ratio > 40) {
            list.add("You have utilized ${String.format("%.0f", ratio)}% of your $formattedBudget budget goal. Fluid capital is allocated correctly.")
        } else {
            list.add("Sovereign, your liquid expense utilization is exceptionally low at ${String.format("%.1f", ratio)}% of the budget. Outstanding balance preservation.")
        }

        // Insight 2: Category highlights
        val foodExp = transactions.filter { it.type == "expense" && it.category == "Food" }.sumOf { it.amount }
        val foodRatio = if (totalExpenses > 0) (foodExp / totalExpenses) * 100 else 0.0
        if (foodRatio > 25) {
            list.add("Fine dining and culinary indulgence represents ${String.format("%.1f", foodRatio)}% of your total expenses. Consider moderating premium culinary orders.")
        } else {
            list.add("Your fine dining spending is highly conservative at ${String.format("%.1f", foodRatio)}% of outbound capital. Excellent discipline.")
        }

        // Insight 3: Performance of assets
        if (investmentProfitPercent > 15.0) {
            list.add("Your investment portfolio is outperforming benchmark indexes with a stunning yield of +${String.format("%.1f", investmentProfitPercent)}% ROI. Rebalancing to secure high yields is highly optimal.")
        } else if (investmentProfitPercent > 0) {
            list.add("Your diversified asset holdings (London Real Estate, VC, Gold) are pacing positive gains (+${String.format("%.1f", investmentProfitPercent)}% yield). Inflation resistance is secure.")
        } else {
            list.add("Diversification check: S&P and Gold hedge structures remain robust. Keep monitor of the short-term capital allocations.")
        }

        list
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("ai_insight_feed"),
        colors = CardDefaults.cardColors(containerColor = WealthCardBg),
        shape = RoundedCornerShape(16.dp),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(WealthGold.copy(alpha = 0.25f)))
    ) {
        Column(
            modifier = Modifier.padding(20.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.AutoAwesome,
                    contentDescription = "AI Insight",
                    tint = WealthGold,
                    modifier = Modifier.size(18.dp)
                )
                Text(
                    text = "AI WEALTH INSIGHTS",
                    style = MaterialTheme.typography.titleSmall,
                    color = WealthGold,
                    letterSpacing = 1.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            Column(
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                insights.forEach { insight ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(WealthGold.copy(alpha = 0.03f), RoundedCornerShape(10.dp))
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "✨",
                            fontSize = 14.sp
                        )
                        Text(
                            text = insight,
                            style = MaterialTheme.typography.bodySmall,
                            color = WealthTextPrimary,
                            lineHeight = 18.sp,
                            fontWeight = FontWeight.Light
                        )
                    }
                }
            }
        }
    }
}

// Map Category to Specific Beautiful Colors
fun getCategoryColor(category: String): Color {
    return when (category) {
        "Food" -> CategoryFood
        "Transport" -> CategoryTransport
        "Shopping" -> CategoryShopping
        "Bills" -> CategoryBills
        "Entertainment" -> CategoryEntertainment
        else -> CategoryOthers
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ManageAlertsDialog(
    investment: Investment,
    viewModel: WealthViewModel,
    onDismiss: () -> Unit
) {
    val alerts by viewModel.alerts.collectAsState()
    val preferredLocale by viewModel.preferredLocale.collectAsState()

    var targetPriceStr by remember { mutableStateOf("") }
    var isAbove by remember { mutableStateOf(true) }
    var customPriceStr by remember { mutableStateOf(investment.currentValue.toString()) }

    val investmentAlerts = remember(alerts, investment.id) {
        alerts.filter { it.investmentId == investment.id }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false),
        modifier = Modifier
            .fillMaxWidth(0.95f)
            .padding(16.dp)
            .testTag("manage_alerts_dialog"),
        content = {
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = WealthCardBg,
                border = androidx.compose.foundation.BorderStroke(1.dp, WealthGold.copy(alpha = 0.2f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .padding(24.dp)
                        .verticalScroll(androidx.compose.foundation.rememberScrollState())
                ) {
                    // Header Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "ALERT CONTROLLER",
                                style = MaterialTheme.typography.labelSmall,
                                color = WealthGold,
                                letterSpacing = 1.5.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = investment.name,
                                style = MaterialTheme.typography.titleLarge,
                                color = WealthTextPrimary,
                                fontWeight = FontWeight.Light,
                                modifier = Modifier.padding(top = 2.dp)
                            )
                        }
                        IconButton(
                            onClick = onDismiss,
                            modifier = Modifier.testTag("close_alerts_dialog")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Close",
                                tint = WealthTextMuted
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Current Holding status
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color.White.copy(alpha = 0.03f), RoundedCornerShape(12.dp))
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "CURRENT HOLDING VALUE",
                                style = MaterialTheme.typography.labelSmall,
                                color = WealthTextMuted
                            )
                            Text(
                                text = investment.currentValue.toCurrencyString(preferredLocale, includeDecimals = true),
                                style = MaterialTheme.typography.headlineSmall,
                                color = WealthGold,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = WealthGold.copy(alpha = 0.1f)
                        ) {
                            Text(
                                text = "Cost: " + investment.amountInvested.toCurrencyString(preferredLocale, includeDecimals = false),
                                style = MaterialTheme.typography.bodySmall,
                                color = WealthGold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    // Section 1: Set Price Alert
                    Text(
                        text = "CREATE PRICE ALERT",
                        style = MaterialTheme.typography.labelMedium,
                        color = WealthGold,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Input target threshold price
                    OutlinedTextField(
                        value = targetPriceStr,
                        onValueChange = { targetPriceStr = it },
                        label = { Text("Target Price Threshold", color = WealthTextMuted) },
                        placeholder = { Text("e.g. 52000.0", color = WealthTextMuted.copy(alpha = 0.5f)) },
                        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                            keyboardType = androidx.compose.ui.text.input.KeyboardType.Number
                        ),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = WealthTextPrimary,
                            unfocusedTextColor = WealthTextPrimary,
                            focusedBorderColor = WealthGold,
                            unfocusedBorderColor = Color.White.copy(alpha = 0.1f),
                            cursorColor = WealthGold,
                            focusedContainerColor = Color.Transparent,
                            unfocusedContainerColor = Color.Transparent
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("alert_target_price_input")
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Above / Below selection
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = { isAbove = true },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isAbove) WealthGold.copy(alpha = 0.15f) else Color.White.copy(alpha = 0.03f),
                                contentColor = if (isAbove) WealthGold else WealthTextMuted
                            ),
                            border = androidx.compose.foundation.BorderStroke(1.dp, if (isAbove) WealthGold else Color.White.copy(alpha = 0.08f)),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("alert_direction_above")
                        ) {
                            Icon(Icons.Default.ArrowUpward, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Rises Above", style = MaterialTheme.typography.bodyMedium)
                        }

                        Button(
                            onClick = { isAbove = false },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (!isAbove) WealthGold.copy(alpha = 0.15f) else Color.White.copy(alpha = 0.03f),
                                contentColor = if (!isAbove) WealthGold else WealthTextMuted
                            ),
                            border = androidx.compose.foundation.BorderStroke(1.dp, if (!isAbove) WealthGold else Color.White.copy(alpha = 0.08f)),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("alert_direction_below")
                        ) {
                            Icon(Icons.Default.ArrowDownward, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Falls Below", style = MaterialTheme.typography.bodyMedium)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            val price = targetPriceStr.toDoubleOrNull()
                            if (price != null && price > 0) {
                                viewModel.addAlert(
                                    investmentId = investment.id,
                                    investmentName = investment.name,
                                    targetPrice = price,
                                    isAbove = isAbove
                                )
                                targetPriceStr = ""
                            } else {
                                viewModel.showSnackbar("Enter a valid target threshold price")
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = WealthGold,
                            contentColor = Color.Black
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("save_alert_button")
                    ) {
                        Icon(Icons.Default.Notifications, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Establish Threshold Trigger", fontWeight = FontWeight.Bold)
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    // Section 2: Update current value / Mock Simulation
                    Text(
                        text = "UPDATE CURRENT MARKET VALUE",
                        style = MaterialTheme.typography.labelMedium,
                        color = WealthGold,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = customPriceStr,
                            onValueChange = { customPriceStr = it },
                            placeholder = { Text("New holding price", color = WealthTextMuted.copy(alpha = 0.5f)) },
                            keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                                keyboardType = androidx.compose.ui.text.input.KeyboardType.Number
                            ),
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = WealthTextPrimary,
                                unfocusedTextColor = WealthTextPrimary,
                                focusedBorderColor = WealthGold,
                                unfocusedBorderColor = Color.White.copy(alpha = 0.1f),
                                cursorColor = WealthGold,
                                focusedContainerColor = Color.Transparent,
                                unfocusedContainerColor = Color.Transparent
                            ),
                            modifier = Modifier
                                .weight(1.3f)
                                .testTag("update_market_price_input")
                        )

                        Button(
                            onClick = {
                                val newPrice = customPriceStr.toDoubleOrNull()
                                if (newPrice != null && newPrice > 0) {
                                    viewModel.updateInvestmentValue(investment, newPrice)
                                } else {
                                    viewModel.showSnackbar("Enter a valid decimal price value")
                                }
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color.White.copy(alpha = 0.08f),
                                contentColor = WealthTextPrimary
                            ),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.15f)),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(56.dp)
                                .testTag("update_market_price_button")
                        ) {
                            Text("Update Value", style = MaterialTheme.typography.bodyMedium)
                        }
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    // Section 3: Existing Alerts
                    Text(
                        text = "ACTIVE ALERTS FOR THIS ASSET",
                        style = MaterialTheme.typography.labelMedium,
                        color = WealthGold,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    if (investmentAlerts.isEmpty()) {
                        Text(
                            text = "No alerts configured for this asset",
                            style = MaterialTheme.typography.bodySmall,
                            color = WealthTextMuted,
                            modifier = Modifier.padding(vertical = 12.dp)
                        )
                    } else {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            investmentAlerts.forEach { alert ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(Color.White.copy(alpha = 0.02f), RoundedCornerShape(8.dp))
                                        .padding(horizontal = 12.dp, vertical = 10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = if (alert.isTriggered) Icons.Default.Notifications else Icons.Default.NotificationsActive,
                                            contentDescription = null,
                                            tint = if (alert.isTriggered) WealthTextMuted else WealthGold,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Column {
                                            Text(
                                                text = if (alert.isAbove) "Triggers when rises above:" else "Triggers when falls below:",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = WealthTextMuted
                                            )
                                            Text(
                                                text = alert.targetPrice.toCurrencyString(preferredLocale, includeDecimals = true),
                                                style = MaterialTheme.typography.bodyMedium,
                                                color = if (alert.isTriggered) WealthTextMuted else WealthTextPrimary,
                                                fontWeight = FontWeight.Bold
                                            )
                                            if (alert.isTriggered) {
                                                Text(
                                                    text = "Status: Triggered & Notified",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = WealthGreen,
                                                    fontWeight = FontWeight.Bold
                                                )
                                            }
                                        }
                                    }

                                    IconButton(
                                        onClick = { viewModel.deleteAlert(alert) },
                                        modifier = Modifier.testTag("delete_alert_btn_${alert.id}")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.DeleteOutline,
                                            contentDescription = "Delete Alert",
                                            tint = WealthRed.copy(alpha = 0.8f),
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    )
}

@Composable
fun PriceAlertsCard(
    viewModel: WealthViewModel,
    modifier: Modifier = Modifier
) {
    val alerts by viewModel.alerts.collectAsState()
    val preferredLocale by viewModel.preferredLocale.collectAsState()

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("price_alerts_card"),
        colors = CardDefaults.cardColors(containerColor = WealthCardBg),
        shape = RoundedCornerShape(16.dp),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(Color.White.copy(alpha = 0.05f)))
    ) {
        Column(
            modifier = Modifier.padding(20.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "THRESHOLD ALERTS",
                        style = MaterialTheme.typography.titleSmall,
                        color = WealthTextMuted,
                        letterSpacing = 1.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "Active price threshold targets",
                        style = MaterialTheme.typography.bodySmall,
                        color = WealthTextMuted
                    )
                }
                Icon(
                    imageVector = Icons.Default.NotificationsActive,
                    contentDescription = "Alerts",
                    tint = WealthGold,
                    modifier = Modifier.size(20.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (alerts.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Tap on an investment holding above to establish a price alert trigger.",
                        style = MaterialTheme.typography.bodySmall,
                        color = WealthTextMuted,
                        textAlign = TextAlign.Center
                    )
                }
            } else {
                Column(
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    alerts.forEach { alert ->
                        val conditionText = if (alert.isAbove) "rises above" else "falls below"
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color.White.copy(alpha = 0.02f), RoundedCornerShape(8.dp))
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(
                                    text = alert.investmentName,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = WealthTextPrimary,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Alerts if price $conditionText ${alert.targetPrice.toCurrencyString(preferredLocale, includeDecimals = true)}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = WealthTextMuted
                                )
                                if (alert.isTriggered) {
                                    Text(
                                        text = "Status: Triggered & Notified",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = WealthGreen,
                                        fontWeight = FontWeight.Bold
                                    )
                                } else {
                                    Text(
                                        text = "Status: Monitoring",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = WealthGold,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            IconButton(
                                onClick = { viewModel.deleteAlert(alert) },
                                modifier = Modifier.testTag("delete_dashboard_alert_${alert.id}")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.DeleteOutline,
                                    contentDescription = "Delete Alert",
                                    tint = WealthRed.copy(alpha = 0.8f),
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
