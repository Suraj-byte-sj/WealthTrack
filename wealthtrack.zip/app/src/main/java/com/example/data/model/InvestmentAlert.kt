package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "investment_alerts")
data class InvestmentAlert(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val investmentId: Int,
    val investmentName: String,
    val targetPrice: Double,
    val isAbove: Boolean, // true if alert when price goes ABOVE, false if BELOW
    val isTriggered: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)
