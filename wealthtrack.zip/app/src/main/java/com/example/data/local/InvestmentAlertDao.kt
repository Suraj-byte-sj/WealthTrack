package com.example.data.local

import androidx.room.*
import com.example.data.model.InvestmentAlert
import kotlinx.coroutines.flow.Flow

@Dao
interface InvestmentAlertDao {
    @Query("SELECT * FROM investment_alerts ORDER BY createdAt DESC")
    fun getAllAlerts(): Flow<List<InvestmentAlert>>

    @Query("SELECT * FROM investment_alerts WHERE isTriggered = 0")
    fun getActiveAlerts(): Flow<List<InvestmentAlert>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAlert(alert: InvestmentAlert)

    @Update
    suspend fun updateAlert(alert: InvestmentAlert)

    @Delete
    suspend fun deleteAlert(alert: InvestmentAlert)

    @Query("DELETE FROM investment_alerts")
    suspend fun clearAlerts()
}
