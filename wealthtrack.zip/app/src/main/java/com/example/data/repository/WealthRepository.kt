package com.example.data.repository

import com.example.data.local.InvestmentAlertDao
import com.example.data.local.InvestmentDao
import com.example.data.local.TransactionDao
import com.example.data.model.Investment
import com.example.data.model.InvestmentAlert
import com.example.data.model.Transaction
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import java.util.UUID

class WealthRepository(
    private val transactionDao: TransactionDao,
    private val investmentDao: InvestmentDao,
    private val investmentAlertDao: InvestmentAlertDao
) {
    val allTransactions: Flow<List<Transaction>> = transactionDao.getAllTransactions()
    val allInvestments: Flow<List<Investment>> = investmentDao.getAllInvestments()
    val allAlerts: Flow<List<InvestmentAlert>> = investmentAlertDao.getAllAlerts()
    val activeAlerts: Flow<List<InvestmentAlert>> = investmentAlertDao.getActiveAlerts()

    suspend fun insertTransaction(transaction: Transaction) {
        transactionDao.insertTransaction(transaction)
    }

    suspend fun deleteTransaction(transaction: Transaction) {
        transactionDao.deleteTransaction(transaction)
    }

    suspend fun insertInvestment(investment: Investment) {
        investmentDao.insertInvestment(investment)
    }

    suspend fun deleteInvestment(investment: Investment) {
        investmentDao.deleteInvestment(investment)
    }

    suspend fun insertAlert(alert: InvestmentAlert) {
        investmentAlertDao.insertAlert(alert)
    }

    suspend fun updateAlert(alert: InvestmentAlert) {
        investmentAlertDao.updateAlert(alert)
    }

    suspend fun deleteAlert(alert: InvestmentAlert) {
        investmentAlertDao.deleteAlert(alert)
    }

    suspend fun clearAll() {
        transactionDao.clearTransactions()
        investmentDao.clearInvestments()
        investmentAlertDao.clearAlerts()
    }

    suspend fun seedDatabaseIfEmpty() {
        // Check if database is empty by getting first elements
        val currentTransactions = transactionDao.getAllTransactions().first()
        val currentInvestments = investmentDao.getAllInvestments().first()

        if (currentTransactions.isEmpty() && currentInvestments.isEmpty()) {
            // Seed 5 Investments
            val defaultInvestments = listOf(
                Investment(name = "Prime London Real Estate", amountInvested = 2500000.0, currentValue = 2950000.0, purchaseDate = "2024-03-15"),
                Investment(name = "Tech VC Fund III", amountInvested = 1000000.0, currentValue = 1450000.0, purchaseDate = "2024-06-20"),
                Investment(name = "S&P 500 Index Fund", amountInvested = 3000000.0, currentValue = 3450000.0, purchaseDate = "2023-01-10"),
                Investment(name = "Bitcoin Core Holdings", amountInvested = 500000.0, currentValue = 850000.0, purchaseDate = "2023-11-05"),
                Investment(name = "Physical Gold Bullion", amountInvested = 1000000.0, currentValue = 1080000.0, purchaseDate = "2024-01-22")
            )

            for (investment in defaultInvestments) {
                investmentDao.insertInvestment(investment)
            }

            // Seed 10 Transactions
            val now = System.currentTimeMillis()
            val dayMs = 24 * 60 * 60 * 1000L
            val defaultTransactions = listOf(
                Transaction(amount = 150000.0, category = "Others", date = now - 9 * dayMs, description = "Venture Capital Dividend", type = "income"),
                Transaction(amount = 250000.0, category = "Others", date = now - 8 * dayMs, description = "Tech Startup Exit Payout", type = "income"),
                Transaction(amount = 25000.0, category = "Others", date = now - 7 * dayMs, description = "Prime Real Estate Rent", type = "income"),
                Transaction(amount = 45000.0, category = "Transport", date = now - 6 * dayMs, description = "Private Jet Charter to Zurich", type = "expense"),
                Transaction(amount = 1800.0, category = "Food", date = now - 5 * dayMs, description = "Michelin 3-Star Dining (L'Ambroisie)", type = "expense"),
                Transaction(amount = 8500.0, category = "Shopping", date = now - 4 * dayMs, description = "Savile Row Bespoke Suit", type = "expense"),
                Transaction(amount = 12500.0, category = "Bills", date = now - 3 * dayMs, description = "Villa Maintenance & Security", type = "expense"),
                Transaction(amount = 35000.0, category = "Entertainment", date = now - 2 * dayMs, description = "Amalfi Coast Yacht Rental", type = "expense"),
                Transaction(amount = 120000.0, category = "Shopping", date = now - dayMs, description = "Contemporary Art Acquisition", type = "expense"),
                Transaction(amount = 15000.0, category = "Entertainment", date = now, description = "Golf Club Annual Dues", type = "expense")
            )

            for (transaction in defaultTransactions) {
                transactionDao.insertTransaction(transaction)
            }
        }
    }
}
