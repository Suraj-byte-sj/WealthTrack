package com.example.util

import java.text.NumberFormat
import java.util.Locale

object CurrencyFormatter {

    // Supported user options for selection
    enum class CurrencyLocale(val displayName: String, val locale: Locale, val symbol: String) {
        SYSTEM("System Default", Locale.getDefault(), "$"),
        US("United States (USD, $)", Locale.US, "$"),
        UK("United Kingdom (GBP, £)", Locale.UK, "£"),
        FRANCE("France (EUR, €)", Locale.FRANCE, "€"),
        GERMANY("Germany (EUR, €)", Locale.GERMANY, "€"),
        INDIA("India (INR, ₹)", Locale("en", "IN"), "₹"),
        JAPAN("Japan (JPY, ¥)", Locale.JAPAN, "¥"),
        CANADA("Canada (CAD, CA$)", Locale.CANADA, "CA$");

        companion object {
            fun fromName(name: String): CurrencyLocale {
                return try {
                    valueOf(name)
                } catch (e: Exception) {
                    SYSTEM
                }
            }
        }
    }

    /**
     * Formats a Double amount into a currency string based on the chosen CurrencyLocale.
     * If includeDecimals is true, it displays decimals, otherwise it formats as integer.
     */
    fun format(
        amount: Double,
        currencyLocale: CurrencyLocale = CurrencyLocale.SYSTEM,
        includeDecimals: Boolean = true
    ): String {
        // Resolve locale to handle dynamic changes in System locale
        val resolvedLocale = if (currencyLocale == CurrencyLocale.SYSTEM) {
            Locale.getDefault()
        } else {
            currencyLocale.locale
        }

        return try {
            val formatter = NumberFormat.getCurrencyInstance(resolvedLocale)
            if (!includeDecimals) {
                formatter.maximumFractionDigits = 0
            } else {
                formatter.maximumFractionDigits = 2
            }
            formatter.format(amount)
        } catch (e: Exception) {
            // Fallback to manual formatting if any locale issue happens
            val symbol = currencyLocale.symbol
            if (includeDecimals) {
                String.format(Locale.US, "%s%,.2f", symbol, amount)
            } else {
                String.format(Locale.US, "%s%,.0f", symbol, amount)
            }
        }
    }
}

/**
 * Extension function to easily format a Double as a currency string.
 */
fun Double.toCurrencyString(
    currencyLocale: CurrencyFormatter.CurrencyLocale,
    includeDecimals: Boolean = true
): String {
    return CurrencyFormatter.format(this, currencyLocale, includeDecimals)
}
