package com.example

import com.example.data.model.Investment
import com.example.data.model.Transaction
import org.junit.Assert.assertEquals
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun testNetWorthCalculation() {
        // Base baselines
        val baseCash = 1000000.0
        val baseLiabilities = 300000.0

        // Mock data
        val mockTransactions = listOf(
            Transaction(amount = 100000.0, category = "Others", date = 0L, description = "Salary", type = "income"),
            Transaction(amount = 20000.0, category = "Food", date = 0L, description = "Luxury dining", type = "expense")
        )

        val mockInvestments = listOf(
            Investment(name = "S&P 500 Index Fund", amountInvested = 500000.0, currentValue = 550000.0, purchaseDate = "2024"),
            Investment(name = "Gold Bullion", amountInvested = 100000.0, currentValue = 110000.0, purchaseDate = "2024")
        )

        // Math logic
        val totalIncomes = mockTransactions.filter { it.type == "income" }.sumOf { it.amount }
        val totalExpenses = mockTransactions.filter { it.type == "expense" }.sumOf { it.amount }
        val currentInvestmentsValue = mockInvestments.sumOf { it.currentValue }

        val liquidCash = baseCash + totalIncomes - totalExpenses
        val totalAssets = liquidCash + currentInvestmentsValue
        val totalLiabilities = baseLiabilities

        val netWorth = totalAssets - totalLiabilities

        // Assertions
        assertEquals(1080000.0, liquidCash, 0.01)
        assertEquals(660000.0, currentInvestmentsValue, 0.01)
        assertEquals(1740000.0, totalAssets, 0.01)
        assertEquals(1440000.0, netWorth, 0.01)
    }

    @Test
    fun testTransactionAdditionUpdatesTotals() {
        val transactions = mutableListOf(
            Transaction(amount = 5000.0, category = "Others", date = 0L, description = "Interest", type = "income"),
            Transaction(amount = 1200.0, category = "Transport", date = 0L, description = "Fuel", type = "expense")
        )

        val totalBefore = transactions.filter { it.type == "income" }.sumOf { it.amount } -
                transactions.filter { it.type == "expense" }.sumOf { it.amount }
        assertEquals(3800.0, totalBefore, 0.01)

        // Add a new transaction
        transactions.add(Transaction(amount = 2500.0, category = "Shopping", date = 0L, description = "Watches", type = "expense"))

        val totalAfter = transactions.filter { it.type == "income" }.sumOf { it.amount } -
                transactions.filter { it.type == "expense" }.sumOf { it.amount }
        assertEquals(1300.0, totalAfter, 0.01)
    }

    @Test
    fun testSpendingCategoryTotalsCalculation() {
        val transactions = listOf(
            Transaction(amount = 150.0, category = "Food", date = 0L, description = "Lunch", type = "expense"),
            Transaction(amount = 350.0, category = "Food", date = 0L, description = "Dinner party", type = "expense"),
            Transaction(amount = 200.0, category = "Transport", date = 0L, description = "Cab", type = "expense"),
            Transaction(amount = 1000.0, category = "Shopping", date = 0L, description = "Suit", type = "expense"),
            Transaction(amount = 5000.0, category = "Others", date = 0L, description = "VC Payout", type = "income") // should ignore incomes
        )

        val categoryTotals = mutableMapOf<String, Double>()
        transactions.filter { it.type == "expense" }.forEach {
            categoryTotals[it.category] = (categoryTotals[it.category] ?: 0.0) + it.amount
        }

        assertEquals(500.0, categoryTotals["Food"] ?: 0.0, 0.01)
        assertEquals(200.0, categoryTotals["Transport"] ?: 0.0, 0.01)
        assertEquals(1000.0, categoryTotals["Shopping"] ?: 0.0, 0.01)
        assertEquals(0.0, categoryTotals["Others"] ?: 0.0, 0.01) // Others is 0.0 as the only "Others" transaction is an income
    }
}
