package com.example

import android.app.Application
import android.content.Context
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.test.core.app.ApplicationProvider
import com.example.viewmodel.WealthViewModel
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @get:Rule
    val composeTestRule = createComposeRule()

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        // Assert updated app name WealthTrack
        assertEquals("WealthTrack", appName)
    }

    @Test
    fun `test add transaction flow displays dialog`() {
        val application = ApplicationProvider.getApplicationContext<Application>()
        val viewModel = WealthViewModel(application)

        composeTestRule.setContent {
            MainContainer(viewModel = viewModel)
        }

        // Verify Dashboard is visible and contains Net Worth
        composeTestRule.onNodeWithTag("net_worth_card").assertIsDisplayed()

        // Click Add Transaction FAB
        composeTestRule.onNodeWithTag("add_transaction_fab").performClick()
        composeTestRule.waitForIdle()

        // Verify the record entry dialog is shown
        composeTestRule.onNodeWithTag("add_transaction_dialog").assertIsDisplayed()

        // Type values and wait for each state change
        composeTestRule.onNodeWithTag("dialog_amount_input").performTextReplacement("150000")
        composeTestRule.waitForIdle()

        composeTestRule.onNodeWithTag("dialog_description_input").performTextReplacement("Real Estate Selloff")
        composeTestRule.waitForIdle()

        // Select Category 'Others'
        composeTestRule.onNodeWithTag("dialog_category_chip_Others").performScrollTo().performClick()
        composeTestRule.waitForIdle()

        // Record type 'income'
        composeTestRule.onNodeWithTag("dialog_type_income").performScrollTo().performClick()
        composeTestRule.waitForIdle()

        // Click Record entry
        composeTestRule.onNodeWithTag("dialog_submit_button").performScrollTo().performClick()
        composeTestRule.waitForIdle()

        // Verify dialog is dismissed
        composeTestRule.onNodeWithTag("add_transaction_dialog").assertDoesNotExist()
    }
}
